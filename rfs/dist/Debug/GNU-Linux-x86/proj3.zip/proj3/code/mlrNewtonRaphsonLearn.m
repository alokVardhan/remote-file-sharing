function [W] = mlrNewtonRaphsonLearn(initial_W, X, T, n_iter)
%mlrNewtonRaphsonLearn learns the weight vector of multi-class Logistic
%Regresion using Newton-Raphson method
% Input:
% initial_W: matrix of size (D+1) x 10 represents the initial weight matrix 
%            for iterative method
% X: matrix of feature vector which size is N x D where N is number of
%            samples and D is number of feature in a feature vector
% T: the label matrix of size N x 10 where each row represent the one-of-K
%    encoding of the true label of corresponding feature vector
% n_inter: maximum number of iterations in Newton Raphson method
%
% Output:
% W: matrix of size (D+1) x 10, represented the learned weight obatained by
%    using Newton-Raphson method

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%W = zeros(size(X, 2) + 1, 10); % dummy return
[row col] = size(X);
disp(size(T));
oneCol = ones(row,1);
x_bias = horzcat(oneCol,X);
%disp(size(x_bias));
initial_W = reshape(initial_W, size(X, 2) + 1, size(T, 2));
%disp(size(initial_W));
col_n=col
N=row;
[row1,col1]=size(initial_W);
J=col1;
K=col1;
Q=[];
H=[];
P=[];
I=eye(10);
for i = 1:n_iter
    a_n =  (x_bias*initial_W);
 %   disp(size(a_n));
    disp(size(exp(a_n)));
    disp(size(logsumexp(a_n,2)));
    y_n=bsxfun(@rdivide,exp(a_n),sum(exp(a_n),2));
    disp(size(y_n));
    disp(size(T));
    sub1=y_n-T;
    
    del_e=x_bias' *sub1;
    disp(size(del_e));
%     R=dot(y_n',(1-y_n)');
%     disp(size(R));
%     H=x_bias'*diag(sparse(R'))*x_bias;
  for j=1:J
    P=[];
      for k=1:K
          Q=zeros(row1,row1);
          disp(size(Q));
        for n=1:N
            temp=x_bias(n,:);
            disp(size(temp));
            Q=Q+((y_n(n,k)*(I(k,j)-y_n(n,j))).*(temp'*temp));
        end
        Q=-1.*Q;
        P=horzcat(P,Q);
      end
    H=vertcat(H,P);
end
del_e=reshape(del_e, size(H, 1),1);
    disp(size(del_e));
    sub=pinv(H)*del_e;
    sub=reshape(sub,row1,col1);
    initial_W=initial_W - sub;
end
W = initial_W; 
end
