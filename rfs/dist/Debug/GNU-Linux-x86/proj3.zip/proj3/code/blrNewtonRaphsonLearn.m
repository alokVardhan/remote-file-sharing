function [w] = blrNewtonRaphsonLearn(initial_w, X, t, n_iter)
%blrNewtonRaphsonLearn learns the weight vector of 2-class Logistic
%Regresion using Newton-Raphson method
% Input:
% initial_w: vector of size (D+1) x 1 where D is the number of features in
%            feature vector
% X: matrix of feature vector which size is N x D where N is number of
%            samples and D is number of feature in a feature vector
% t: vector of size N x 1 where each entry is either 0 or 1 representing
%    the true label of corresponding feature vector.
% n_inter: maximum number of iterations in Newton Raphson method
%
% Output:
% w: vector of size (D+1) x 1, represented the learned weight obatained by
%    using Newton-Raphson method

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%w = zeros(size(X, 2) + 1, 1); % dummy return
[row col] = size(X);
oneCol = ones(row,1);
x_bias = horzcat(oneCol,X);
for i = 1:n_iter
    y_n =  sigmoid(x_bias*initial_w);
    del_e=x_bias' *(y_n-t); 
    R=y_n.*(1-y_n);
    H=x_bias'*diag(sparse(R))*x_bias;
    initial_w=initial_w - (pinv(H)*del_e);
end
w = initial_w; 
end
