function [label] = mlrPredict(W, X)
% blrObjFunction predicts the label of data given the data and parameter W
% of multi-class Logistic Regression
%
% Input:
% W: the matrix of weight of size (D + 1) x 10
% X: the data matrix of size N x D
%
% Output: 
% label: vector of size N x 1 representing the predicted label of
%        corresponding feature vector given in data matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
label = zeros(size(X, 1), 1); % dummy return
[row,col] = size(X);
oneCol = ones(row,1);
x_bias = horzcat(oneCol,X);
a_n = x_bias*W;
y_n = sigmoid(a_n);
for i = 1:row
    [x label(i)] = max(y_n(i,:));
end
end