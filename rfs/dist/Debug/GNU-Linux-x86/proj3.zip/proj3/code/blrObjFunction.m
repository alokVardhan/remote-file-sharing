function [error, error_grad] = blrObjFunction(w, X, t)
% blrObjFunction computes 2-class Logistic Regression error function and
% its gradient.
%
% Input:
% w: the weight vector of size (D + 1) x 1 
% X: the data matrix of size N x D
% t: the label vector of size N x 1 where each entry can be either 0 or 1
%    representing the label of corresponding feature vector
%
% Output: 
% error: the scalar value of error function of 2-class logistic regression
% error_grad: the vector of size (D+1) x 1 representing the gradient of
%             error function


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[row,col] = size(X);
oneCol = ones(row,1);
a_n = zeros(row,1);
y_n = zeros(row,1);

X_bias = zeros(row,col + 1);
X_bias = horzcat(oneCol,X);
a_n = X_bias*w; %% N*(D+1) * (D+1)*1
y_n1 = 1.0 ./(1.0 + exp(-a_n));
y_n=y_n1;
%%tn' * In(yn) + (1 - tn)'*In(1 - yn) 

e1 = t'*log(y_n);
e2 = (1-t)'*log(1-y_n);
error = -(e1 + e2); % dummy return
diff =  y_n - t;
error_grad = X_bias'*(diff); % (D+1)*N * N*1


end
