function [error, error_grad] = mlrObjFunction(W, X, T)
% mlrObjFunction computes multi-class Logistic Regression error function 
% and its gradient.
%
% Input:
% W: the vector of size ((D + 1) * 10) x 1. Later on, it will reshape into
%    matrix of size D + 1) x 10
% X: the data matrix of size N x D
% T: the label matrix of size N x 10 where each row represent the one-of-K
%    encoding of the true label of corresponding feature vector
%
% Output: 
% error: the scalar value of error function of 2-class logistic regression
% error_grad: the vector of size ((D+1) * 10) x 1 representing the gradient 
%             of error function


W = reshape(W, size(X, 2) + 1, size(T, 2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[row, col] = size(X);
oneCol = zeros(row,1);
x_bias = horzcat(oneCol,X);
a_n = x_bias*W;
n_n = a_n;
d_n = logsumexp(a_n,2);
y_n = bsxfun(@rdivide,n_n,d_n);
sum1 =  sum(T.*y_n,2);
error = -sum(sum1); % dummy return
n_ngrad = exp(a_n);
d_ngrad = sum(n_ngrad,2);
y_ngrad = bsxfun(@rdivide,n_ngrad,d_ngrad);
diff = y_ngrad - T;
error_grad = x_bias'*diff;

error_grad = reshape(error_grad,(size(X,2) + 1)*10,1);

end
